<?php
include ".vista";

server(all);
?>